def dijkstra(graph, start, end):
    # Inicializar las distancias a infinito para todos los nodos, excepto el nodo de inicio
    distances = {node: float('inf') for node in graph}
    distances[start] = 0

    # Crear un conjunto para almacenar los nodos visitados
    visited = set()

    while True:
        # Encontrar el nodo no visitado con la distancia más corta
        min_distance = float('inf')
        min_node = None
        for node in graph:
            if node not in visited and distances[node] < min_distance:
                min_distance = distances[node]
                min_node = node

        if min_node is None:
            break

        # Marcar el nodo como visitado
        visited.add(min_node)

        # Actualizar las distancias de los nodos vecinos no visitados
        for neighbor, weight in graph[min_node].items():
            if neighbor not in visited:
                distance = distances[min_node] + weight
                if distance < distances[neighbor]:
                    distances[neighbor] = distance

    return distances[end]

# Ejemplo de uso:
graph = {
    'A': {'B': 1, 'C': 4},
    'B': {'C': 2, 'D': 5},
    'C': {'D': 1},
    'D': {}
}
start_node = 'A'
end_node = 'D'

shortest_distance = dijkstra(graph, start_node, end_node)
print("Ruta más corta desde el nodo A al nodo D:", shortest_distance)