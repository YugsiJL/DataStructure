def multiply_matrices(A, B):
    n = len(A)

    if n == 1:
        return [[A[0][0] * B[0][0]]]

    mid = n // 2

    A11 = [A[i][:mid] for i in range(mid)]
    A12 = [A[i][mid:] for i in range(mid)]
    A21 = [A[i][:mid] for i in range(mid, n)]
    A22 = [A[i][mid:] for i in range(mid, n)]

    B11 = [B[i][:mid] for i in range(mid)]
    B12 = [B[i][mid:] for i in range(mid)]
    B21 = [B[i][:mid] for i in range(mid, n)]
    B22 = [B[i][mid:] for i in range(mid, n)]

    C11 = matrix_add(multiply_matrices(A11, B11), multiply_matrices(A12, B21))
    C12 = matrix_add(multiply_matrices(A11, B12), multiply_matrices(A12, B22))
    C21 = matrix_add(multiply_matrices(A21, B11), multiply_matrices(A22, B21))
    C22 = matrix_add(multiply_matrices(A21, B12), multiply_matrices(A22, B22))

    return [C11[i] + C12[i] for i in range(mid)] + [C21[i] + C22[i] for i in range(mid)]

def matrix_add(A, B):
    return [[A[i][j] + B[i][j] for j in range(len(A[i]))] for i in range(len(A))]

# Ejemplo de uso:
A = [[2, 3], [4, 5]]
B = [[1, 2], [3, 4]]

resultado = multiply_matrices(A, B)
print(resultado)  # Salida: [[11, 16], [19, 28]]