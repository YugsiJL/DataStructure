def solve_n_queens(n):
    def is_safe(board, row, col):
        # Verificar si es seguro colocar una reina en la posición (row, col)
        # Verificar la fila
        for i in range(col):
            if board[row][i] == 1:
                return False

        # Verificar la diagonal izquierda hacia arriba
        for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
            if board[i][j] == 1:
                return False

        # Verificar la diagonal izquierda hacia abajo
        for i, j in zip(range(row, n), range(col, -1, -1)):
            if board[i][j] == 1:
                return False

        return True

    def backtrack(col):
        # Caso base: si todas las reinas están colocadas, agregamos el tablero a la lista de resultados
        if col == n:
            results.append([''.join('Q' if board[i][j] == 1 else '.' for j in range(n)) for i in range(n)])
            return

        for row in range(n):
            if is_safe(board, row, col):
                board[row][col] = 1
                backtrack(col + 1)  # Llamada recursiva para colocar la siguiente reina en la siguiente columna
                board[row][col] = 0  # Deshacer el cambio para explorar otras posibilidades (backtrack)

    # Inicializar el tablero como una matriz de ceros
    board = [[0 for _ in range(n)] for _ in range(n)]
    results = []

    # Empezar la exploración desde la primera columna
    backtrack(0)
    return results

# Ejemplo de uso:
n = 4
solutions = solve_n_queens(n)
for solution in solutions:
    for row in solution:
        print(row)
    print()