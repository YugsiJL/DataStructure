def find_valid_paths(maze, start, end):
    """
    Encuentra todas las soluciones válidas para resolver un laberinto desde el punto de inicio
    hasta el punto de llegada utilizando el algoritmo de backtracking.

    :param maze: Laberinto representado como una matriz (lista de listas) de 0's y 1's.
    :param start: Coordenadas (fila, columna) del punto de inicio.
    :param end: Coordenadas (fila, columna) del punto de llegada.
    :return: Lista de todas las soluciones válidas como una lista de listas de coordenadas.
    """

    def is_valid_move(row, col):
        """
        Verifica si un movimiento a una posición es válido.

        :param row: Fila de la posición a verificar.
        :param col: Columna de la posición a verificar.
        :return: True si el movimiento es válido (casilla en el laberinto y no es una pared), False en caso contrario.
        """
        return 0 <= row < rows and 0 <= col < cols and maze[row][col] == 0

    def backtrack(row, col, current_path):
        """
        Función de backtracking para encontrar todas las soluciones válidas.

        :param row: Fila actual en el laberinto.
        :param col: Columna actual en el laberinto.
        :param current_path: Lista que almacena el camino actual en construcción.
        """
        nonlocal all_paths

        # Si llegamos al punto de llegada, agregamos el camino actual a la lista de soluciones
        if (row, col) == end:
            all_paths.append(list(current_path))  # Agregamos una copia del camino actual
            return

        # Verificamos y marcamos la casilla actual como visitada (1)
        maze[row][col] = 1
        current_path.append((row, col))

        # Exploramos los movimientos posibles: arriba, abajo, izquierda y derecha
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            new_row, new_col = row + dr, col + dc

            # Si el movimiento es válido, seguimos explorando desde la nueva posición
            if is_valid_move(new_row, new_col):
                backtrack(new_row, new_col, current_path)

        # Deshacemos el movimiento (backtrack) y marcamos la casilla actual como no visitada (0)
        maze[row][col] = 0
        current_path.pop()

    # Tamaño del laberinto (filas y columnas)
    rows, cols = len(maze), len(maze[0])

    # Lista para almacenar todas las soluciones válidas
    all_paths = []

    # Comenzamos el backtracking desde el punto de inicio
    start_row, start_col = start
    backtrack(start_row, start_col, [])

    return all_paths

# Ejemplo de uso:
maze = [
    [0, 1, 0, 0, 0],
    [0, 0, 0, 1, 0],
    [1, 1, 0, 1, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0]
]
start_point = (0, 0)  # Coordenadas del punto de inicio
end_point = (4, 4)    # Coordenadas del punto de llegada

result = find_valid_paths(maze, start_point, end_point)
print("Soluciones válidas:")
for path in result:
    print(path)
