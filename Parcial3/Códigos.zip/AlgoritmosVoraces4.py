def activity_selection(start_times, end_times):
    n = len(start_times)
    activities = list(range(n))

    # Ordenar las actividades por tiempo de finalización ascendente
    activities.sort(key=lambda x: end_times[x])

    selected_activities = [activities[0]]
    last_end_time = end_times[activities[0]]

    for i in range(1, n):
        activity = activities[i]
        if start_times[activity] >= last_end_time:
            selected_activities.append(activity)
            last_end_time = end_times[activity]

    return selected_activities

# Ejemplo de uso:
start_times = [1, 3, 0, 5, 8, 5]
end_times = [2, 4, 6, 7, 9, 9]

selected_activities = activity_selection(start_times, end_times)
print("Máxima cantidad de actividades no superpuestas:")
print(selected_activities)