def find_combinations(elements, subset_size):
    """
    Encuentra todas las combinaciones posibles de un conjunto de elementos para formar subconjuntos
    con un tamaño específico utilizando el algoritmo de backtracking.

    :param elements: Lista de elementos del conjunto.
    :param subset_size: Tamaño de los subconjuntos que queremos formar.
    :return: Lista de todas las combinaciones válidas.
    """

    def backtrack(start, current_combination):
        """
        Función de backtracking para encontrar todas las combinaciones válidas.

        :param start: Índice de inicio para explorar nuevos elementos.
        :param current_combination: Lista que almacena la combinación actual en construcción.
        """
        nonlocal all_combinations

        # Si hemos alcanzado el tamaño deseado para el subconjunto, agregamos la combinación actual
        if len(current_combination) == subset_size:
            all_combinations.append(list(current_combination))  # Agregamos una copia de la combinación actual
            return

        # Continuamos explorando nuevos elementos desde el índice 'start'
        for i in range(start, len(elements)):
            current_combination.append(elements[i])  # Agregamos el elemento actual a la combinación

            # Llamada recursiva para continuar construyendo la combinación
            backtrack(i + 1, current_combination)

            current_combination.pop()  # Retrocedemos y eliminamos el último elemento para probar otras combinaciones

    # Lista para almacenar todas las combinaciones válidas
    all_combinations = []

    # Comenzamos el backtracking desde el primer elemento
    backtrack(0, [])

    return all_combinations

# Ejemplo de uso:
elements = [1, 2, 3, 4, 5]   # Conjunto de elementos
subset_size = 3             # Tamaño deseado para los subconjuntos

result = find_combinations(elements, subset_size)
print("Combinaciones posibles:")
for combination in result:
    print(combination)
