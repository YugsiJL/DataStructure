def subset_sum(nums, target):
    n = len(nums)
    dp = [[False for _ in range(target + 1)] for _ in range(n + 1)]

    for i in range(n + 1):
        dp[i][0] = True

    for i in range(1, n + 1):
        for j in range(1, target + 1):
            if nums[i - 1] <= j:
                dp[i][j] = dp[i - 1][j] or dp[i - 1][j - nums[i - 1]]
            else:
                dp[i][j] = dp[i - 1][j]

    return dp[n][target]

# Ejemplo de uso:
conjunto = [3, 34, 4, 12, 5, 2]
suma_objetivo = 9

resultado = subset_sum(conjunto, suma_objetivo)
if resultado:
    print("Es posible obtener la suma objetivo.")
else:
    print("No es posible obtener la suma objetivo.")