def find_combinations(coins, target_amount, current_combination, results): 

current_sum = sum(current_combination) 

 
 

if current_sum == target_amount: 

results.append(current_combination[:]) # Agregar una copia de la combinación actual a los resultados 

return 

elif current_sum > target_amount: 

return 

 
 

for coin in coins: 

current_combination.append(coin) 

find_combinations(coins, target_amount, current_combination, results) 

current_combination.pop() # Retroceder y probar sin incluir la moneda actual 

 
 

def coin_combinations(coins, target_amount): 

results = [] 

find_combinations(coins, target_amount, [], results) 

return results 

 
 

# Código principal 

if __name__ == "__main__": 

coins_available = [1, 5, 10, 25, 50, 100] # Ejemplo de conjunto de monedas disponibles 

target_amount = 50 # Ejemplo de cantidad objetivo 

 
 

combinations = coin_combinations(coins_available, target_amount) 

 
 

if combinations: 

print(f"Todas las combinaciones de monedas para {target_amount} son:") 

for combination in combinations: 

print(combination) 

else: 

print(f"No se encontraron combinaciones para dar un cambio exacto de {target_amount}.") 