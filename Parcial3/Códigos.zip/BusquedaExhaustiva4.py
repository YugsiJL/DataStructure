def find_paths(maze, start, end): 

def is_valid_move(row, col): 

# Verifica si el movimiento está dentro de los límites del laberinto y si es un pasillo (0). 

return 0 <= row < len(maze) and 0 <= col < len(maze[0]) and maze[row][col] == 0 

 
 

def explore_path(row, col, path): 

# Si la celda actual está fuera de los límites del laberinto o es un muro (1), la ruta no es válida. 

if not is_valid_move(row, col): 

return 

 
 

# Agregar la celda actual a la ruta actual. 

path.append((row, col)) 

 
 

# Si alcanzamos el punto de llegada, agregamos la ruta actual a las rutas encontradas. 

if (row, col) == end: 

paths.append(path[:]) 

 
 

# Marcar la celda actual como visitada. 

maze[row][col] = 1 

 
 

# Explorar todas las direcciones posibles: arriba, abajo, izquierda y derecha. 

for dr, dc in [(1, 0), (-1, 0), (0, 1), (0, -1)]: 

explore_path(row + dr, col + dc, path) 

 
 

# Desmarcar la celda actual para permitir que otras rutas la utilicen. 

maze[row][col] = 0 

 
 

# Eliminar la celda actual de la ruta para retroceder en la recursión. 

path.pop() 

 
 

# Lista para almacenar las rutas encontradas. 

paths = [] 

 
 

# Comenzar la búsqueda exhaustiva desde el punto de inicio. 

explore_path(start[0], start[1], []) 

 
 

return paths 

 
 

# Ejemplo de uso 

maze = [ 

[0, 1, 0, 0], 

[0, 0, 0, 1], 

[0, 1, 0, 0], 

[0, 0, 0, 0] 

] 

start_point = (0, 0) 

end_point = (3, 3) 

 
 

all_paths = find_paths(maze, start_point, end_point) 

print("Todas las rutas posibles:") 

for path in all_paths: 

print(path)