def find_permutations(original_str): 

def generate_permutations(remaining_str, current_permutation, all_permutations): 

if len(remaining_str) == 0: 

all_permutations.append(current_permutation) 

return 

 
 

for i in range(len(remaining_str)): 

next_permutation = current_permutation + remaining_str[i] 

remaining_chars = remaining_str[:i] + remaining_str[i + 1:] 

generate_permutations(remaining_chars, next_permutation, all_permutations) 

 
 

all_permutations = [] 

generate_permutations(original_str, "", all_permutations) 

return all_permutations 

 
 

# Ejemplo de uso: 

input_str = "abc" 

permutations = find_permutations(input_str) 

for permutation in permutations: 

print(permutation) 