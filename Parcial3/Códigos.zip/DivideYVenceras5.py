import random


def quickselect(arr, k):
    if len(arr) == 1:
        return arr[0]

    pivot = random.choice(arr)
    smaller = [x for x in arr if x < pivot]
    equal = [x for x in arr if x == pivot]
    larger = [x for x in arr if x > pivot]

    if k <= len(smaller):
        return quickselect(smaller, k)
    elif k <= len(smaller) + len(equal):
        return pivot
    else:
        return quickselect(larger, k - len(smaller) - len(equal))

# Ejemplo de uso:
lista_numeros = [9, 3, 7, 2, 5, 10, 4]
k_esimo = 3
resultado = quickselect(lista_numeros, k_esimo)
print(f"El elemento {k_esimo}-ésimo más pequeño es: {resultado}")
