def mochila_fraccional(elementos, capacidad_mochila): 

# Calcula la relación valor/peso para cada elemento 

for elemento in elementos: 

elemento['relacion'] = elemento['valor'] / elemento['peso'] 

 
 

# Ordena los elementos por su relación valor/peso en orden decreciente 

elementos.sort(key=lambda x: x['relacion'], reverse=True) 

 
 

valor_total = 0 

cantidades_seleccionadas = {} 

 
 

for elemento in elementos: 

peso_disponible = capacidad_mochila - sum(cantidades_seleccionadas.values()) 

 
 

if peso_disponible >= elemento['peso']: 

# Agregar el elemento completo a la mochila 

cantidades_seleccionadas[elemento['nombre']] = elemento['peso'] 

valor_total += elemento['valor'] 

else: 

# Agregar una fracción del elemento a la mochila 

fraccion = peso_disponible / elemento['peso'] 

cantidades_seleccionadas[elemento['nombre']] = fraccion * elemento['peso'] 

valor_total += fraccion * elemento['valor'] 

break # Rompemos el bucle, ya que no podemos agregar más elementos 

 
 

return valor_total, cantidades_seleccionadas 

 
 

# Ejemplo de uso 

elementos = [ 

{'nombre': 'A', 'valor': 10, 'peso': 2}, 

{'nombre': 'B', 'valor': 5, 'peso': 3}, 

{'nombre': 'C', 'valor': 15, 'peso': 5}, 

{'nombre': 'D', 'valor': 7, 'peso': 7}, 

{'nombre': 'E', 'valor': 6, 'peso': 1}, 

] 

 
 

capacidad_mochila = 10 

valor_total, cantidades_seleccionadas = mochila_fraccional(elementos, capacidad_mochila) 

 
 

print("Valor total en la mochila:", valor_total) 

print("Elementos seleccionados:") 

for elemento, cantidad in cantidades_seleccionadas.items(): 

print(f"{elemento}: {cantidad} unidades.")