import sys


def distance(city1, city2):
    # Función para calcular la distancia euclidiana entre dos ciudades
    return ((city1[0] - city2[0])**2 + (city1[1] - city2[1])**2) ** 0.5

def nearest_neighbor_tsp(cities):
    n = len(cities)
    visited = [False] * n
    path = [0]  # Comenzamos en la ciudad 0 (ciudad de origen)
    visited[0] = True

    for _ in range(n - 1):
        current_city = path[-1]
        nearest_distance = sys.maxsize
        nearest_city = None

        for i in range(n):
            if not visited[i]:
                dist = distance(cities[current_city], cities[i])
                if dist < nearest_distance:
                    nearest_distance = dist
                    nearest_city = i

        path.append(nearest_city)
        visited[nearest_city] = True

    path.append(0)  # Regresar a la ciudad de origen

    return path

# Ejemplo de uso:
cities = [(0, 0), (1, 2), (2, 4), (3, 1), (4, 3)]

best_path = nearest_neighbor_tsp(cities)
print("Ruta más corta que visita todas las ciudades una vez:", best_path)