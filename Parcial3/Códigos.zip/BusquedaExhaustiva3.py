def find_combinations(nums, target_size): 

def generate_combinations(curr_combination, start): 

# Si el tamaño actual de la combinación es igual al tamaño objetivo, la agregamos a la lista de resultados 

if len(curr_combination) == target_size: 

result.append(curr_combination) 

return 

# Recorremos los elementos del conjunto a partir de la posición 'start' 

for i in range(start, len(nums)): 

# Creamos una nueva combinación agregando el elemento actual 

generate_combinations(curr_combination + [nums[i]], i + 1) 

# Lista para almacenar las combinaciones válidas 

result = [] 

# Iniciamos la generación de combinaciones desde el inicio del conjunto (posición 0) 

generate_combinations([], 0) 

return result 

 
 

# Ejemplo de uso 

conjunto_elementos = [1, 2, 3, 4] 

tamaño_subconjunto = 2 

combinaciones = find_combinations(conjunto_elementos, tamaño_subconjunto) 

print(combinaciones)