def boyer_moore_majority(arr):
    # Paso 1: Encuentra un candidato potencial para el elemento mayoritario
    candidate = None
    count = 0
    for num in arr:
        if count == 0:
            candidate = num
            count = 1
        elif candidate == num:
            count += 1
        else:
            count -= 1
    
    # Paso 2: Verifica si el candidato potencial es realmente el elemento mayoritario
    count = 0
    for num in arr:
        if num == candidate:
            count += 1
    
    if count > len(arr) // 2:
        return candidate
    else:
        return None

# Ejemplo de uso:
lista_numeros = [2, 2, 3, 2, 4, 2, 5, 2, 2]
resultado = boyer_moore_majority(lista_numeros)
if resultado is not None:
    print("El elemento mayoritario es:", resultado)
else:
    print("No hay elemento mayoritario en el arreglo.")