def is_safe(board, row, col, N): 

# Verificar la fila en busca de otras reinas 

for i in range(col): 

if board[row][i] == 1: 

return False 

 
 

# Verificar la diagonal superior izquierda 

for i, j in zip(range(row, -1, -1), range(col, -1, -1)): 

if board[i][j] == 1: 

return False 

 
 

# Verificar la diagonal inferior izquierda 

for i, j in zip(range(row, N), range(col, -1, -1)): 

if board[i][j] == 1: 

return False 

 
 

return True 

 
 

def solve_nqueens(N): 

def backtrack(row): 

# Si hemos llegado a la última fila, hemos encontrado una solución 

if row == N: 

solutions.append([list(row) for row in board]) 

return 

 
 

for col in range(N): 

if is_safe(board, row, col, N): 

board[row][col] = 1 

backtrack(row + 1) 

board[row][col] = 0 # Backtrack 

 
 

solutions = [] 

board = [[0] * N for _ in range(N)] 

backtrack(0) 

return solutions 

 
 

# Ejemplo de uso: 

N = 4 

solutions = solve_nqueens(N) 

 
 

# Imprimir las soluciones encontradas 

for idx, solution in enumerate(solutions): 

print(f"Solución {idx+1}:") 

for row in solution: 

print(" ".join("Q" if val == 1 else "-" for val in row)) 

print()