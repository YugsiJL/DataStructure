def max_non_overlapping_intervals(intervals):
    """
    Resuelve el problema de selección de intervalos utilizando el algoritmo de backtracking
    para encontrar la máxima cantidad de actividades que no se superpongan.

    :param intervals: Lista de tuplas (inicio, fin) que representan los intervalos.
    :return: Lista con la selección de intervalos que no se superponen.
    """

    def is_valid_selection(selection):
        """
        Verifica si una selección de intervalos es válida (no se superponen).

        :param selection: Lista de tuplas (inicio, fin) que representan los intervalos seleccionados.
        :return: True si la selección es válida, False en caso contrario.
        """
        for i in range(len(selection)):
            for j in range(i + 1, len(selection)):
                if selection[i][1] > selection[j][0] and selection[i][0] < selection[j][1]:
                    return False
        return True

    def backtrack(start, current_selection):
        """
        Función de backtracking para encontrar la máxima cantidad de actividades que no se superpongan.

        :param start: Índice de inicio para explorar nuevos intervalos.
        :param current_selection: Lista que almacena la selección actual en construcción.
        """
        nonlocal max_selection

        # Actualizamos la selección máxima si es válida y contiene más intervalos que la selección actual
        if is_valid_selection(current_selection) and len(current_selection) > len(max_selection):
            max_selection = list(current_selection)

        # Continuamos explorando nuevos intervalos desde el índice 'start'
        for i in range(start, len(intervals)):
            current_selection.append(intervals[i])  # Agregamos el intervalo actual a la selección

            # Llamada recursiva para continuar construyendo la selección
            backtrack(i + 1, current_selection)

            current_selection.pop()  # Retrocedemos y eliminamos el último intervalo para probar otras selecciones

    # Ordenamos los intervalos por su tiempo de finalización (para una selección óptima)
    intervals.sort(key=lambda x: x[1])

    # Lista para almacenar la selección máxima de intervalos que no se superponen
    max_selection = []

    # Comenzamos el backtracking desde el primer intervalo
    backtrack(0, [])

    return max_selection

# Ejemplo de uso:
intervals = [(1, 4), (3, 5), (0, 6), (5, 7), (3, 9), (5, 9), (6, 10), (8, 11), (8, 12), (2, 14), (12, 16)]
result = max_non_overlapping_intervals(intervals)
print("Selección máxima de intervalos que no se superponen:")
print(result)
