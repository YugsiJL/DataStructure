INF = float('inf')

def floyd_warshall(graph):
    num_vertices = len(graph)
    dist = [[INF for _ in range(num_vertices)] for _ in range(num_vertices)]

    # Inicializar la matriz de distancias con los pesos de las aristas conocidas
    for u in range(num_vertices):
        for v, weight in graph[u].items():
            dist[u][v] = weight

    # Calcular las distancias más cortas entre todos los pares de vértices
    for k in range(num_vertices):
        for i in range(num_vertices):
            for j in range(num_vertices):
                if dist[i][k] + dist[k][j] < dist[i][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]

    return dist

# Ejemplo de uso:
graph = {
    0: {1: 3, 2: 6},
    1: {0: 3, 2: 2, 3: 1},
    2: {0: 6, 1: 2, 3: 4},
    3: {1: 1, 2: 4}
}

result = floyd_warshall(graph)
for row in result:
    print(row)