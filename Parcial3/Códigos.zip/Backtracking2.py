def knapsack_backtracking(values, weights, capacity):
    """
    Resuelve el problema de la mochila 0-1 utilizando el algoritmo de backtracking.
    
    :param values: Lista de valores de los elementos.
    :param weights: Lista de pesos de los elementos.
    :param capacity: Capacidad máxima de la mochila.
    :return: Valor máximo que se puede llevar en la mochila.
    """

    def backtrack(index, current_weight, current_value):
        """
        Función de backtracking para explorar todas las combinaciones posibles.

        :param index: Índice actual del elemento que estamos considerando.
        :param current_weight: Peso acumulado de los elementos en la mochila actual.
        :param current_value: Valor acumulado de los elementos en la mochila actual.
        """
        nonlocal max_value

        # Si llegamos al final de la lista de elementos o excedemos la capacidad de la mochila, terminamos
        if index == len(values) or current_weight >= capacity:
            # Actualizamos el valor máximo si corresponde
            max_value = max(max_value, current_value)
            return

        # Si el elemento actual puede caber en la mochila, exploramos la opción de agregarlo
        if current_weight + weights[index] <= capacity:
            backtrack(index + 1, current_weight + weights[index], current_value + values[index])

        # Exploramos la opción de no agregar el elemento actual
        backtrack(index + 1, current_weight, current_value)

    # Inicializamos la variable para almacenar el valor máximo
    max_value = 0

    # Comenzamos el backtracking desde el primer elemento
    backtrack(0, 0, 0)

    return max_value

# Ejemplo de uso:
values = [60, 100, 120]  # Valores de los elementos
weights = [10, 20, 30]   # Pesos de los elementos
capacity = 50            # Capacidad máxima de la mochila

print("Valor máximo en la mochila:", knapsack_backtracking(values, weights, capacity))
